# Installation Instructions

1. `mkdir build`
2. `cd build`
3. `cmake /path/to/libdlibxx -DCMAKE_INSTALL_PREFIX=/usr`
4. `make`
5. `sudo make install`

